/* TEATOR · layer dinamico (vanilla JS, nessuna dipendenza) */
(() => {
'use strict';
const RM = matchMedia('(prefers-reduced-motion: reduce)').matches;
const $$ = (s, c = document) => [...c.querySelectorAll(s)];
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const smooth = x => x*x*(3 - 2*x);
document.documentElement.classList.add('js');

/* 1 · RIVELAZIONE allo scroll, a ondate sfalsate */
if (!RM && 'IntersectionObserver' in window) {
  const io = new IntersectionObserver(es => es.forEach(e => {
    if (!e.isIntersecting) return;
    const el = e.target; io.unobserve(el); el.classList.add('in');
    el.addEventListener('transitionend', () => { el.classList.remove('rv','in'); el.style.transitionDelay = ''; }, {once:true});
  }), {threshold:.15});
  $$('.wow').forEach((el, i) => { el.classList.add('rv'); el.style.transitionDelay = (i % 4)*90 + 'ms'; io.observe(el); });
}

/* 2 · COREOGRAFIA: indice per l'onda delle liste */
$$('#METODO .cfp ul, #SPETTACOLI .proceedings-box ul').forEach(ul =>
  $$('li', ul).forEach((li, i) => li.style.setProperty('--i', i)));

/* 3 · BARRA DI AVANZAMENTO + RUOTA "torna su" */
const bar = document.body.appendChild(Object.assign(document.createElement('div'), {id:'tprog'}));
const wheel = document.createElement('button');
wheel.id = 'twheel'; wheel.type = 'button'; wheel.setAttribute('aria-label', 'Torna all\'inizio della pagina');
const ticks = [0,45,90,135,180,225,270,315].map(a =>
  `<line x1="0" y1="-26" x2="0" y2="-33" transform="rotate(${a})" stroke="#fff" stroke-width="5" stroke-linecap="round"/>`).join('');
wheel.innerHTML = `<svg viewBox="-50 -50 100 100" aria-hidden="true"><g id="twr"><circle r="42" fill="none" stroke="#fff" stroke-width="7"/>${ticks}</g>` +
  `<path d="M-30 0Q0-22 30 0Q0 22-30 0Z" fill="#000" stroke="#fff" stroke-width="5"/><circle id="twp" r="8" fill="#fff"/></svg>`;
document.body.appendChild(wheel);
const twr = wheel.querySelector('#twr'), twp = wheel.querySelector('#twp');
wheel.addEventListener('click', () => scrollTo({top:0, behavior: RM ? 'auto' : 'smooth'}));
const onScroll = () => {
  const max = (document.documentElement.scrollHeight - innerHeight) || 1;
  bar.style.transform = `scaleX(${clamp(scrollY/max, 0, 1)})`;
  wheel.classList.toggle('on', scrollY > 300);
};
addEventListener('scroll', onScroll, {passive:true}); onScroll();

/* puntatore globale (usato da occhio e stormo) */
let gx = -999, gy = -999;
addEventListener('pointermove', e => { gx = e.clientX; gy = e.clientY; }, {passive:true});
document.addEventListener('pointerleave', () => { gx = gy = -999; });

/* 4 · INCLINAZIONE CON RIMBALZO (solo mouse/penna) */
$$('.proceedings-box, .col-md-5 > .service-box').forEach(el => {
  el.addEventListener('pointermove', e => {
    if (RM || e.pointerType === 'touch') return;
    const r = el.getBoundingClientRect(), x = (e.clientX - r.left)/r.width, y = (e.clientY - r.top)/r.height;
    el.classList.add('mv');
    el.style.transform = `perspective(1000px) rotateX(${(.5 - y)*4}deg) rotateY(${(x - .5)*5}deg)`;
  });
  el.addEventListener('pointerleave', () => { el.classList.remove('mv'); el.style.transform = ''; });
});

/* 5 · STORMO NELL'HERO: intelligenza di sciame che si sincronizza e forma la ruota con l'occhio del logo */
const hero = document.getElementById('hero'), cv = document.getElementById('swarm');
let swarmStep = null, swarmRun = true;
if (hero && cv) {
  const g = cv.getContext('2d'), cols = ['#ea7516','#16b8ea','#21A0A0','#ffffff'];
  let W, H, P = [], cx, cy, R, rot = 0, lastT = 0, px = 0, py = 0;
  const bg = document.getElementById('parallax');
  function geo() {   // la ruota di back1.jpg (534x445): centro (271.5,165), raggio dell'anello 105; segue cover + parallax
    const hr = hero.getBoundingClientRect(), b = bg ? bg.getBoundingClientRect() : {left:0, top:0, width:innerWidth, height:innerHeight};
    const sc = Math.max(b.width/534, b.height/445);
    cx = b.left + (b.width - 534*sc)/2 + 271.5*sc - hr.left;
    cy = b.top + (b.height - 445*sc)/2 + 165*sc - hr.top;
    R = 105*sc;
  }
  function build() {
    const d = Math.min(devicePixelRatio || 1, 2);
    W = hero.clientWidth; H = hero.clientHeight;
    cv.width = W*d; cv.height = H*d; g.setTransform(d,0,0,d,0,0);
    const narrow = W < 768, n = narrow ? 130 : 240;
    geo();
    const nRing = Math.round(n*.42), nTick = Math.round(n*.16), nLens = Math.round(n*.32), nPup = n - nRing - nTick - nLens;
    P = [];
    const add = o => P.push(Object.assign({x:Math.random()*W, y:Math.random()*H, vx:Math.random()-.5, vy:Math.random()-.5, c:cols[P.length % 4]}, o));
    for (let i = 0; i < nRing; i++) add({k:0, a:i/nRing*Math.PI*2});
    for (let i = 0; i < nTick; i++) add({k:1, a:(i % 8)*Math.PI/4, r:.62 + .28*Math.floor(i/8)/Math.max(1, Math.ceil(nTick/8) - 1)});
    for (let i = 0; i < nLens; i++) add({k:2, s:i % 2 ? -1 : 1, u:((i >> 1)/(nLens/2))*2 - 1});
    for (let i = 0; i < nPup; i++) { const a = Math.random()*6.283, r = Math.sqrt(Math.random())*.2; add({k:3, u:Math.cos(a)*r, s:Math.sin(a)*r}); }
    if (RM) { rot = 0; P.forEach(p => { const t = target(p); p.x = t[0]; p.y = t[1]; p.vx = p.vy = 0; }); }
  }
  function target(p) {
    switch (p.k) {
      case 0: { const a = p.a + rot; return [cx + R*Math.cos(a), cy + R*Math.sin(a)]; }
      case 1: { const a = p.a + rot, r = R*p.r; return [cx + r*Math.cos(a), cy + r*Math.sin(a)]; }
      case 2: return [cx + p.u*.62*R, cy + p.s*.3*R*Math.cos(p.u*Math.PI/2)];
      default: return [cx + px + p.u*R, cy + py + p.s*R];
    }
  }
  const sync = t => { // ciclo di 16 s: libero → si sincronizza → ruota unito → si scioglie
    const u = (t/1000 % 16)/16;
    return u < .3 ? 0 : u < .45 ? smooth((u - .3)/.15) : u < .8 ? 1 : u < .95 ? 1 - smooth((u - .8)/.15) : 0;
  };
  function step(t) {
    const dt = Math.min(.05, (t - lastT)/1000 || .016); lastT = t;
    const s = RM ? 1 : sync(t), free = 1 - s;
    rot += dt*.35*(.3 + .7*s);
    geo();
    const r = hero.getBoundingClientRect(), mx = gx - r.left, my = gy - r.top;
    const dx0 = mx - cx, dy0 = my - cy, has = gx > -900;
    px = has ? clamp(dx0*.15, -.3*R, .3*R) : 0; py = has ? clamp(dy0*.15, -.07*R, .07*R) : 0;
    g.clearRect(0,0,W,H); g.lineCap = 'round'; g.lineWidth = 2.4; g.globalAlpha = .85;
    for (const p of P) {
      if (free > .02) {
        let ax=0, ay=0, ex=0, ey=0, vx=0, vy=0, n=0;
        for (const q of P) { if (q === p) continue;
          const dx = q.x - p.x, dy = q.y - p.y, d2 = dx*dx + dy*dy;
          if (d2 < 4900) { n++; ex += q.x; ey += q.y; vx += q.vx; vy += q.vy; if (d2 < 400) { ax -= dx*.002; ay -= dy*.002; } } }
        if (n) { p.vx += ((ex/n - p.x)*.0006 + (vx/n - p.vx)*.04 + ax)*free; p.vy += ((ey/n - p.y)*.0006 + (vy/n - p.vy)*.04 + ay)*free; }
      }
      if (s > .01) { const tg = target(p); p.vx += (tg[0] - p.x)*.012*s; p.vy += (tg[1] - p.y)*.012*s; p.vx *= 1 - .1*s; p.vy *= 1 - .1*s; }
      if (has) { const dx = p.x - mx, dy = p.y - my, d = Math.hypot(dx, dy) || 1;
        if (d < 100) { p.vx += dx/d*.5; p.vy += dy/d*.5; } }   // il corpo spinge lo sciame
      const sp = Math.hypot(p.vx, p.vy) || .01, lim = 2.4 + 3.6*s, mn = .7*free, tv = clamp(sp, mn, lim);
      p.vx *= tv/sp; p.vy *= tv/sp;
      p.x += p.vx; p.y += p.vy;
      if (free > .5) { p.x = (p.x + W) % W; p.y = (p.y + H) % H; }
      g.strokeStyle = p.c; g.beginPath(); g.moveTo(p.x, p.y); g.lineTo(p.x - p.vx*4 + .01, p.y - p.vy*4); g.stroke();
    }
  }
  swarmStep = step;
  build();
  let rb; addEventListener('resize', () => { clearTimeout(rb); rb = setTimeout(() => { build(); if (RM) step(0); }, 200); });
  hero.addEventListener('pointerdown', e => {   // onda d'urto
    const r = hero.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
    P.forEach(p => { const dx = p.x - x, dy = p.y - y, d = Math.hypot(dx, dy) || 1;
      if (d < 260) { const f = (1 - d/260)*6; p.vx += dx/d*f; p.vy += dy/d*f; } });
  });
  if ('IntersectionObserver' in window) new IntersectionObserver(([e]) => swarmRun = e.isIntersecting).observe(hero);
  if (RM) step(0);
}

/* 6 · CICLO UNICO: ruota del pulsante + stormo */
if (!RM) {
  let wa = 0, lx = 0, ly = 0;
  (function loop(t) {
    requestAnimationFrame(loop);
    if (document.hidden) return;
    if (swarmStep && swarmRun) swarmStep(t);
    wa += (scrollY*.35 - wa)*.12;                       // inerzia: la ruota insegue lo scroll
    twr.setAttribute('transform', `rotate(${wa.toFixed(1)})`);
    const b = wheel.getBoundingClientRect(), dx = gx - (b.left + b.width/2), dy = gy - (b.top + b.height/2);
    const m = Math.hypot(dx, dy) || 1, k = gx > -900 ? Math.min(7, m/40) : 0;
    const x = (dx/m*k), y = (dy/m*k*.35);
    if (x !== lx || y !== ly) { twp.setAttribute('transform', `translate(${x.toFixed(1)} ${y.toFixed(1)})`); lx = x; ly = y; }
  })(0);
}
})();
